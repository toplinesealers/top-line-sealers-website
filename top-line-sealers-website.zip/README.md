# Top Line Sealers Website

This is the starter website for Top Line Sealers.

Files:
- index.html — homepage
- style.css — design and mobile layout
- script.js — menu, year, and form placeholder

Before publishing, replace the logo placeholder, phone, email, service area, photos, and review text with your real business information.
